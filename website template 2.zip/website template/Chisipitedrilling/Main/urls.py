
from django.urls import path
from .views import (
    about,
    index,
    portfolio_details,
    portfolio,
    pricing,
    services,
    team,
    testimonials,
    contact,
)    
app_name = 'Main'
urlpatterns = [
    path('',index,name='index'),
    path('about',about,name='about'),
    path('team',team,name='team'),
    path('Portfolio',portfolio,name='portfolio'),
    path('services',services,name='Services'),
    path('portfolio_details',portfolio_details,name='portfolio_details'),
    path('pricing',pricing,name='pricing'),
    path('testimonials',testimonials,name='testimonials'),
    path('contact',contact,name='Contact') ,
]


