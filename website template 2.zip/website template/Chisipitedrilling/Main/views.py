from django.shortcuts import render


# Create your views here.
def index (request):
    template_name ='Main/index.html' 
    context = {}
    return render(request,template_name,context)

def about(request):
    template_name = 'Main/about.html'
    context = {}
    return render(request,template_name,context)       

def services(request):
    template_name = 'Main/services.html'
    context = {}
    return render(request,template_name,context)

def team(request):
    template_name = 'Main/team.html'
    context = {}
    return render(request,template_name,context)

def portfolio_details(request):
    template_name = 'Main/portfolio_details.html'
    context = {}
    return render(request,template_name,context)

def portfolio(request):
    template_name = 'Main/portfolio.html'
    context = {}
    return render(request,template_name,context)   

def pricing(request):
    template_name = 'Main/pricing.html'
    context = {}
    return render(request,template_name,context)   

def testimonials(request):
    template_name = 'Main/testimonials.html'
    context = {}
    return render(request,template_name,context)

def contact(request):
    template_name = 'Main/contact.html'
    context = {}
    return render(request,template_name,context)      